/*
 * Add your JavaScript to this file to complete the assignment.
 */

/****************
Modal Set up
*****************/
function modal_up() {
    var cancelB = document.getElementsByClassName("modal-cancel-button");
    var acceptB = document.getElementsByClassName("modal-accept-button");
    var closeB = document.getElementsByClassName("modal-close-button");
    cancelB[0].addEventListener('click', modal_d);
    closeB[0].addEventListener('click', modal_d);
    acceptB[0].addEventListener('click', createTwit);
    var modal = document.getElementById("create-twit-modal");
    var modalbackground = document.getElementById("modal-backdrop");
    modal.classList.remove("hidden");
    modalbackground.classList.remove("hidden");
}

var createtwitButton = document.getElementById("create-twit-button");
createtwitButton.addEventListener('click', modal_up)



/*****************
Modal is taken down.
******************/
function modal_d() {
    var modal = document.getElementById("create-twit-modal");
    var modalbackground = document.getElementById("modal-backdrop");
    modal.classList.add("hidden");
    modalbackground.classList.add("hidden");
    var twitTextInput = document.getElementById("twit-text-input");
    var twitAuthorInput = document.getElementById("twit-attribution-input");
    twitTextInput.value = '';
    twitAuthorInput.value = '';
}

/***********
Modal Create and Interaction
************/
function createTwit () {
    var twitTextInput = document.getElementById("twit-text-input");
    var twitAuthorInput = document.getElementById("twit-attribution-input");
    if (twitTextInput.value == '' || twitAuthorInput.value == '') //If either query is empty, error message.
    {
        alert("INVALID INPUT.");
    }
    else
    {
        //Twit structure
        var element = document.createElement("article");
        var imageelem = document.createElement("div");
        var actualimg = document.createElement("i");
        var divelem = document.createElement("div");
        var parelem = document.createElement("p");
        var apar = document.createElement("p");
        var truehref = document.createElement("a");
        //Twit classes.
        truehref.href = "#";
        element.classList.add("twit");
        imageelem.classList.add("twit-icon");
        actualimg.classList.add("fa");
        actualimg.classList.add("fa-bullhorn");
        divelem.classList.add("twit-content");
        parelem.classList.add("twit-text");
        apar.classList.add("twit-attribution");
        //Put twit pieces together.
        element.appendChild(imageelem);
        imageelem.appendChild(actualimg);
        element.appendChild(divelem);
        divelem.appendChild(parelem);
        divelem.appendChild(apar);
        apar.appendChild(truehref);
        //Take user input and put it into text nodes, then append those nodes to corresponding DOM nodes.
        var twitText = document.createTextNode(twitTextInput.value);
        parelem.appendChild(twitText);
        var twitAttr = document.createTextNode(twitAuthorInput.value);
        truehref.appendChild(twitAttr);
        var twitContainer = document.getElementsByClassName("twit-container");
        twitContainer[0].appendChild(element);
        //Close it down after twit addition.
        modal_d();
    }
}

function srch() {
    var text; //This will hold the text content itself.
    var attr; //This will hold the attribute content.
    var userInput; 
    var twitBoxes= document.getElementsByClassName("twit"); //Twit box
    var textArray = document.getElementsByClassName("twit-text"); //Twit text field
    var userSearch = document.getElementById("navbar-search-input"); //Navbar field
    userInput = userSearch.value;
    var attributeArray = document.getElementsByClassName("twit-attribution");//twit attribution text field.
    userInput = userInput.toLowerCase(); //Puts it to lower case to help the search.
    for(var i =0; i < twitBoxes.length; i++) //Loop through all and make it all hidden, this is the base case.
    {
        twitBoxes[i].classList.remove("hidden");
    }
    for(i = 0; i < twitBoxes.length; i++)// Actual search loop.
    {
        text =textArray[i].textContent; 
        text = text.toLowerCase();
        attribute = attributeArray[i].textContent;
        attribute = attribute.toLowerCase();
        if(text.search(userInput) == -1 && attribute.search(userInput) == -1) // If either the text or attribution field is false, set twit to 'hidden'.
        {
            twitBoxes[i].classList.add("hidden");
        }
    }
}
var searchB = document.getElementById("navbar-search-button");
searchB.addEventListener('click', srch);
var searchI = document.getElementById("navbar-search-input");
searchI.addEventListener('input', srch);